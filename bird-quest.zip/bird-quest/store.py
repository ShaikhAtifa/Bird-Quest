"""Saves your sightings in a plain CSV file you can open in Excel.

File: data/sightings.csv   One row per bird per recording.
status is "found" (sure enough), "maybe" (not sure), or "none" (you went
out and recorded, but no bird was heard). A "none" row still counts as a walk.
"""

import csv
from datetime import datetime

import config

FIELDS = ["timestamp", "file", "status", "scientific", "common", "confidence", "place", "note"]
TIME_FORMAT = "%Y-%m-%d %H:%M"


def sightings_path():
    return config.DATA_DIR / "sightings.csv"


def load_sightings() -> list[dict]:
    path = sightings_path()
    if not path.is_file():
        return []
    with open(path, newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def add_rows(rows: list[dict]) -> None:
    path = sightings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    is_new = not path.is_file()
    with open(path, "a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        if is_new:
            writer.writeheader()
        for row in rows:
            writer.writerow({name: row.get(name, "") for name in FIELDS})


def make_row(when: datetime, file: str, status: str, scientific="", common="",
             confidence=None, place="", note="") -> dict:
    return {
        "timestamp": when.strftime(TIME_FORMAT),
        "file": file,
        "status": status,
        "scientific": scientific,
        "common": common,
        "confidence": "" if confidence is None else f"{confidence:.2f}",
        "place": place,
        "note": " ".join(note.split()),
    }


def row_time(row: dict) -> datetime:
    return datetime.strptime(row["timestamp"], TIME_FORMAT)


def species_key(row: dict) -> str:
    return (row.get("scientific") or row.get("common") or "").casefold()

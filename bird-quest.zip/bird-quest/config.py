"""Settings for Bird Quest.

Change the values below to match you. This is the only file you need to edit.
"""

from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"  # your sightings and bingo card are saved here

# --- Where you walk -------------------------------------------------------
# BirdNET uses these two numbers (plus the week of the year) to hide birds
# that do not live near you. They stay on your laptop. Nothing is sent online.
# The default below is Pune. Find yours by searching "my city latitude longitude".
USE_LOCATION = True
LATITUDE = 18.52
LONGITUDE = 73.86

# --- How sure must BirdNET be? -------------------------------------------
MIN_CONFIDENCE = 0.25      # BirdNET reports guesses above this number (its own default)
CONFIRM_CONFIDENCE = 0.50  # at or above this, Bird Quest counts the bird as "found"

# --- The local AI (Ollama) ------------------------------------------------
OLLAMA_HOST = "http://localhost:11434"
# qwen2.5:1.5b is small (about 1 GB), fast on a laptop, and Apache-2.0 licensed.
# For better notes (slower), try "qwen2.5:7b" (also Apache-2.0, about 4.7 GB).
# Run: ollama pull qwen2.5:1.5b
OLLAMA_MODEL = "qwen2.5:1.5b"
OLLAMA_TIMEOUT_SECONDS = 180  # the first answer is slow because the model is loading

# --- Missions -------------------------------------------------------------
EARLY_BIRD_HOUR = 8  # "early bird" missions count recordings made before 8 AM

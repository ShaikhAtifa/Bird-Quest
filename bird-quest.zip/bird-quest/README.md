# Bird Quest

**A weekly bird mission you can only finish by going outside. It runs on open-source AI, on your own laptop, with no internet.**

<!-- BEFORE YOU SUBMIT: search this file for [[ and replace every [[ ... ]] with your own words.
     Delete these comments. Read the whole README out loud once. -->

[[ HOOK: 2 or 3 sentences in your own voice. What happened the first time you used it outside? Start with the moment, not the technology. ]]

## Why I built this

[[ 2 short paragraphs, personal. Suggested questions:
   - When did you last stand outside and listen, with no phone in your hand?
   - Why is it hard to go outside on a normal weekday?
   - What do you want to change? Keep it small and true. ]]

I noticed that most bird apps make the problem worse: they work best when you stare at the screen. I wanted the opposite. I wanted a tool where the screen is the **shortest** part of the experience, and where the reason to open it is a small goal that is only reachable outdoors.

## What it does

Every week Bird Quest gives you one mission, for example *"Find 5 different birds by sound"* or *"Record a bird before 8 AM"*. You go outside and record bird sounds with any phone. Then:

1. **BirdNET** (open-source bird-sound AI) names the birds it hears and says how sure it is.
2. A small **local language model** (through Ollama) writes a 2-sentence field note about each bird: one fact, and one tip to recognise it next time.
3. Birds you are sure about tick off squares on a **3x3 bingo card** and count toward the weekly mission.
4. Everything is saved in a plain CSV file you can open in Excel.

You cannot finish a mission or fill the card from your sofa. The only way to make progress is to walk out and listen.

```
python quest.py mission
python quest.py listen recordings/morning.m4a --place "Pashan Lake" --when "2026-10-12 07:15"
python quest.py card
```

## Why open models matter here

This is not a decoration. The project stops working without the open parts, and each one earns its place:

- **It works with no signal.** Parks and hills often have poor reception. BirdNET and the language model both run on the laptop, so the tool works on the trail. A cloud API would not.
- **Your location stays with you.** BirdNET uses your latitude, longitude and the week of the year to hide birds that do not live near you. With a hosted service, I would be sending my walking habits to a company. Here, nothing leaves the laptop.
- **No account, no cost, no limits.** Anyone can run it, including students, without an API key or a bill.
- **I can see what is inside.** BirdNET's code is public, so I read how it writes its result file and built on that, instead of guessing.

## How it works

```
 recording        BirdNET             Bird Quest              Ollama (local model)
 (phone)   -->  names the birds  -->  keeps only the     -->  writes a 2-sentence
                and how sure          birds it is sure of      field note
                                          |
                                          v
                              sightings.csv, bingo card, weekly mission
```

| Part | What it is | Licence |
|------|------------|---------|
| [BirdNET-Analyzer](https://github.com/birdnet-team/BirdNET-Analyzer) | Bird-sound identification, run as a command | Code: MIT. Models: CC BY-NC-SA 4.0 |
| [Ollama](https://ollama.com) | Runs language models on your computer | Check ollama.com for current terms |
| Qwen2.5 1.5B | The small language model that writes the notes | Apache 2.0 (per its Ollama page) |
| Bird Quest (this repo) | The glue: missions, bingo card, log | MIT |

Files: `quest.py` (commands), `birdnet_runner.py` (runs BirdNET, reads its CSV), `notes.py` (asks the local model), `missions.py`, `bingo.py`, `store.py`, `config.py` (the only file you edit).

### Design choices I made on purpose

- **Honest uncertainty.** BirdNET gives each guess a confidence score. Birds under 50% are shown as "maybe" and **do not count**. A tool that gets people outside should not reward wrong answers.
- **A walk is a day you recorded.** If you go out and hear nothing, that still counts as a walk. Going out is the point.
- **The notes are labelled.** If the local model is not running, Bird Quest still works and says "[no AI]" instead of pretending.
- **Short output.** One quick check, then the phone goes back in the pocket. On Windows, `--speak` can read the field note aloud so the screen is not needed at all.

## Quick start (Windows)

Full step-by-step guide: [docs/SETUP_WINDOWS.md](docs/SETUP_WINDOWS.md).

```
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
ollama pull qwen2.5:1.5b
python quest.py warmup      # one time, needs internet: downloads BirdNET's model
python quest.py check       # is everything ready?
```

Edit `config.py` to put your own latitude and longitude. Then run `python quest.py newcard` to get a bingo card made from the birds BirdNET expects near you at this time of year.

## What the output looks like

> **Illustration only. This is the format, not a real walk. Replace it with a real output from your own recording.**

```
Listening to morning.m4a ...
Found:
  House Crow (Corvus splendens)  93% sure
    [AI note appears here]
Maybe (not counted, under 50% sure):
  Common Myna  34%

Bingo: ticked House Crow  (1/9)
This week's mission: Find 5 different birds by sound  [1/5]
```

## Field test

[[ This is the heart of the write-up. Fill it from docs/field-report-template.md. Write it as a short story with real numbers. Include:
   - Where and when you went, the weather, how long you stayed
   - Whether the laptop was offline
   - How many birds BirdNET named, how many you could check, how many were right or wrong
   - How many times you looked at the screen, and for how long
   - One moment you would have missed if you had stayed home
   - Photos of the setup (and of the place) ]]

## What does not work well

[[ Replace or extend with your own findings. Real limits I already know about: ]]

- BirdNET is a good guide, not a judge. Wind, traffic, and distant birds lower its accuracy. Always treat a result as "probably".
- The location filter hides birds that are rare in your area, so a rare visitor may be missed or mislabelled.
- A 1.5-billion-parameter model can write a wrong fact with a confident voice. The notes are AI-written. Check them before you share them.
- Weekly missions run on trust. The program cannot prove you walked.
- BirdNET needs the internet **once**, to download its model. After that it is fully offline.
- The automated tests use fake BirdNET and Ollama answers (BirdNET's real output format was read from its source code). Real bird detection quality is what the field test measures.

## What I would build next

[[ 2 or 3 ideas from your own experience. For example: recording directly on the phone, a map of where each bird was heard, a "bird of the week" to learn by ear. ]]

## Run the tests

```
python -m unittest discover -s tests -v
```

## Credits and licences

- **BirdNET** by the K. Lisa Yang Center for Conservation Bioacoustics at the Cornell Lab of Ornithology and Chemnitz University of Technology. Please cite: Kahl, S., Wood, C. M., Eibl, M., & Klinck, H. (2021). *BirdNET: A deep learning solution for avian diversity monitoring.* Ecological Informatics, 61, 101236. BirdNET's models are CC BY-NC-SA 4.0 (educational and research use is non-commercial), so Bird Quest is a non-commercial project.
- **Ollama** and **Qwen2.5** by the Qwen team at Alibaba Cloud.
- [[ Any recordings you did not make yourself: author, source, licence. ]]

## How this was built

[[ Be open about how you worked. For example: "I built this as a first open-source project. I used an AI assistant (Claude) as a tutor and to help write the first version of the code, then I installed, ran, and tested everything myself and wrote the field test and this README." Write what is true for you. ]]

Licence: MIT. See [LICENSE](LICENSE).

"""Talks to BirdNET, the open-source bird-sound AI, and reads what it finds.

BirdNET is a separate tool (pip package "birdnet_analyzer"). We start it as a
command, ask for a CSV result file, and read that file. We do not touch its
insides, so it keeps working even when BirdNET updates its code.
"""

import csv
import importlib.util
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

import config


class BirdNetError(RuntimeError):
    """BirdNET failed or gave us something we cannot read."""


@dataclass(frozen=True)
class Detection:
    start: float
    end: float
    scientific: str
    common: str
    confidence: float


def birdnet_week(when: datetime) -> int:
    """BirdNET counts 4 weeks in every month, so its weeks go from 1 to 48."""
    week_in_month = min(4, (when.day - 1) // 7 + 1)
    return (when.month - 1) * 4 + week_in_month


def parse_results_csv(path) -> list[Detection]:
    """Read BirdNET's CSV file (columns: Start (s), End (s), Scientific name,
    Common name, Confidence, File)."""
    detections = []
    with open(path, newline="", encoding="utf-8", errors="replace") as handle:
        for row in csv.DictReader(handle):
            try:
                detections.append(
                    Detection(
                        start=float(row["Start (s)"]),
                        end=float(row["End (s)"]),
                        scientific=row["Scientific name"].strip(),
                        common=row["Common name"].strip(),
                        confidence=float(row["Confidence"]),
                    )
                )
            except (KeyError, ValueError, TypeError, AttributeError) as err:
                raise BirdNetError(
                    f"Could not read BirdNET's result file ({err}). "
                    "BirdNET may have changed its output format."
                ) from err
    return detections


def best_per_species(detections: list[Detection]) -> list[Detection]:
    """BirdNET checks every 3 seconds, so one bird can appear many times.
    Keep the most confident hit for each species, best first."""
    best: dict[str, Detection] = {}
    for item in detections:
        key = (item.scientific or item.common).casefold()
        if key not in best or item.confidence > best[key].confidence:
            best[key] = item
    return sorted(best.values(), key=lambda d: d.confidence, reverse=True)


def model_downloaded() -> bool:
    """BirdNET downloads its model file the first time it runs (internet needed
    once). After that it works fully offline."""
    spec = importlib.util.find_spec("birdnet_analyzer")
    if spec is None or not spec.submodule_search_locations:
        return False
    package_dir = Path(list(spec.submodule_search_locations)[0])
    return (package_dir / "checkpoints" / "V2.4" / "BirdNET_GLOBAL_6K_V2.4_Model_FP32.tflite").is_file()


def _explain_failure(result) -> str:
    """Turn a BirdNET crash into a message a beginner can act on."""
    text = f"{result.stderr or ''}\n{result.stdout or ''}"
    tail = "\n".join(text.strip().splitlines()[-4:])
    if "No module named" in text:
        hint = "BirdNET is not installed in this Python. Fix: pip install -r requirements.txt"
    elif any(word in text for word in ("ProxyError", "ConnectionError", "Max retries", "Failed to download")):
        hint = ("BirdNET needs the internet ONCE to download its model file. "
                "Connect to Wi-Fi, then run: python quest.py warmup")
    else:
        hint = "BirdNET stopped with an error. Run the same command with --debug to see everything."
    return f"{hint}\n\nLast lines from BirdNET:\n{tail}"


def _location_args(when: datetime) -> list[str]:
    if not config.USE_LOCATION:
        return []
    return [
        "--lat", str(config.LATITUDE),
        "--lon", str(config.LONGITUDE),
        "--week", str(birdnet_week(when)),
    ]


def run_birdnet(audio_path, when: datetime | None = None, debug: bool = False) -> list[Detection]:
    """Analyze one audio file (wav, mp3, m4a, ogg, flac...) and return detections."""
    audio_path = Path(audio_path)
    if not audio_path.is_file():
        raise FileNotFoundError(f"I cannot find the recording: {audio_path}")

    when = when or datetime.now()
    out_dir = tempfile.mkdtemp(prefix="birdquest_")
    command = [
        sys.executable, "-m", "birdnet_analyzer.analyze",
        str(audio_path),
        "-o", out_dir,
        "--rtype", "csv",
        "--min_conf", str(config.MIN_CONFIDENCE),
        *_location_args(when),
    ]
    result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if debug:
        print(result.stdout)
        print(result.stderr)
    if result.returncode != 0:
        raise BirdNetError(_explain_failure(result))

    result_files = list(Path(out_dir).rglob("*.BirdNET.results.csv"))
    if not result_files:
        return []  # BirdNET ran fine but wrote nothing: it heard no bird above the limit
    return parse_results_csv(result_files[0])


def list_local_species(when: datetime | None = None) -> list[tuple[str, str]]:
    """Ask BirdNET which species live near you at this time of year.
    Returns (scientific name, common name) pairs, most common first."""
    when = when or datetime.now()
    out_file = Path(tempfile.mkdtemp(prefix="birdquest_")) / "species_list.txt"
    command = [
        sys.executable, "-m", "birdnet_analyzer.species",
        str(out_file),
        "--sortby", "freq",
        *_location_args(when),
    ]
    result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if result.returncode != 0 or not out_file.is_file():
        raise BirdNetError(_explain_failure(result))
    species = []
    for line in out_file.read_text(encoding="utf-8", errors="replace").splitlines():
        scientific, _, common = line.strip().partition("_")
        if scientific and common:
            species.append((scientific, common))
    return species

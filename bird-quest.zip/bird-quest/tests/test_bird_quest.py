"""Run with:  python -m unittest discover -s tests -v

These tests do not need BirdNET or Ollama. They check our own logic using a
sample result file in BirdNET's real CSV format and a pretend AI.
"""

import contextlib
import io
import sys
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import bingo  # noqa: E402
import birdnet_runner  # noqa: E402
import config  # noqa: E402
import missions  # noqa: E402
import notes  # noqa: E402
import quest  # noqa: E402
import store  # noqa: E402

FIXTURE = ROOT / "tests" / "fixtures" / "sample.BirdNET.results.csv"


class TempData(unittest.TestCase):
    """Every test gets its own empty data folder."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        patcher = mock.patch.object(config, "DATA_DIR", Path(self._tmp.name))
        patcher.start()
        self.addCleanup(patcher.stop)
        self.addCleanup(self._tmp.cleanup)


class TestBirdNetParsing(unittest.TestCase):
    def test_reads_all_rows(self):
        detections = birdnet_runner.parse_results_csv(FIXTURE)
        self.assertEqual(len(detections), 4)
        self.assertEqual(detections[0].common, "House Crow")
        self.assertAlmostEqual(detections[0].confidence, 0.8123)

    def test_best_per_species_keeps_highest_confidence_first(self):
        best = birdnet_runner.best_per_species(birdnet_runner.parse_results_csv(FIXTURE))
        self.assertEqual([d.common for d in best], ["House Crow", "Asian Koel", "Common Myna"])
        self.assertAlmostEqual(best[0].confidence, 0.9321)

    def test_bad_file_gives_clear_error(self):
        bad = Path(tempfile.mkdtemp()) / "bad.csv"
        bad.write_text("a,b\n1,2\n", encoding="utf-8")
        with self.assertRaises(birdnet_runner.BirdNetError):
            birdnet_runner.parse_results_csv(bad)

    def test_birdnet_week_runs_1_to_48(self):
        self.assertEqual(birdnet_runner.birdnet_week(datetime(2026, 1, 1)), 1)
        self.assertEqual(birdnet_runner.birdnet_week(datetime(2026, 10, 11)), 38)
        self.assertEqual(birdnet_runner.birdnet_week(datetime(2026, 12, 31)), 48)


class TestBirdNetErrors(unittest.TestCase):
    def _result(self, stderr):
        return mock.Mock(returncode=1, stdout="", stderr=stderr)

    def test_download_problem_points_to_warmup(self):
        message = birdnet_runner._explain_failure(self._result("requests.exceptions.ProxyError: Max retries"))
        self.assertIn("python quest.py warmup", message)

    def test_missing_install_points_to_pip(self):
        message = birdnet_runner._explain_failure(self._result("No module named birdnet_analyzer"))
        self.assertIn("pip install -r requirements.txt", message)

    def test_run_birdnet_raises_clear_error_on_crash(self):
        audio = Path(tempfile.mkdtemp()) / "a.wav"
        audio.write_bytes(b"x")
        with mock.patch("subprocess.run", return_value=self._result("ConnectionError")):
            with self.assertRaises(birdnet_runner.BirdNetError) as ctx:
                birdnet_runner.run_birdnet(audio)
        self.assertIn("warmup", str(ctx.exception))

    def test_no_result_file_means_no_birds(self):
        audio = Path(tempfile.mkdtemp()) / "a.wav"
        audio.write_bytes(b"x")
        ok = mock.Mock(returncode=0, stdout="", stderr="")
        with mock.patch("subprocess.run", return_value=ok):
            self.assertEqual(birdnet_runner.run_birdnet(audio), [])

    def test_command_uses_csv_and_location(self):
        audio = Path(tempfile.mkdtemp()) / "a.wav"
        audio.write_bytes(b"x")
        ok = mock.Mock(returncode=0, stdout="", stderr="")
        with mock.patch("subprocess.run", return_value=ok) as run:
            birdnet_runner.run_birdnet(audio, when=datetime(2026, 10, 11, 7, 0))
        command = run.call_args.args[0]
        self.assertIn("birdnet_analyzer.analyze", command)
        self.assertEqual(command[command.index("--rtype") + 1], "csv")
        self.assertEqual(command[command.index("--week") + 1], "38")
        self.assertEqual(command[command.index("--lat") + 1], str(config.LATITUDE))


class TestNotes(unittest.TestCase):
    def test_fallback_when_ollama_is_off(self):
        import urllib.error
        with mock.patch("urllib.request.urlopen", side_effect=urllib.error.URLError("down")):
            text, source = notes.field_note("House Crow", "Corvus splendens")
        self.assertEqual(source, "fallback")
        self.assertIn("House Crow", text)

    def test_uses_ollama_answer(self):
        fake = mock.MagicMock()
        fake.__enter__.return_value.read.return_value = b'{"response": "  A noisy bird.\\n Listen for it. ", "done": true}'
        with mock.patch("urllib.request.urlopen", return_value=fake):
            text, source = notes.field_note("House Crow", "Corvus splendens")
        self.assertEqual(source, "ollama")
        self.assertEqual(text, "A noisy bird. Listen for it.")


class TestMissions(TempData):
    def _row(self, when, status="found", sci="Corvus splendens", common="House Crow", place=""):
        return store.make_row(datetime.strptime(when, "%Y-%m-%d %H:%M"), "a.wav", status,
                              sci, common, 0.9, place)

    def test_species_mission_counts_distinct_found_birds_only(self):
        mission = missions.MISSIONS[0]
        rows = [
            self._row("2026-10-12 07:00"),
            self._row("2026-10-12 07:05"),  # same bird again
            self._row("2026-10-13 18:00", sci="Acridotheres tristis", common="Common Myna"),
            self._row("2026-10-13 18:01", status="maybe", sci="Columba livia", common="Rock Pigeon"),
        ]
        self.assertEqual(missions.progress(mission, rows, datetime(2026, 10, 14, 9, 0)), (2, 5))

    def test_walks_count_days_even_when_no_bird_heard(self):
        mission = missions.MISSIONS[1]
        rows = [self._row("2026-10-12 07:00"),
                self._row("2026-10-13 07:00", status="none", sci="", common=""),
                self._row("2026-10-14 07:00")]
        self.assertEqual(missions.progress(mission, rows, datetime(2026, 10, 14, 9, 0))[0], 3)

    def test_last_week_does_not_count(self):
        mission = missions.MISSIONS[0]
        rows = [self._row("2026-10-05 07:00")]  # the Monday before
        self.assertEqual(missions.progress(mission, rows, datetime(2026, 10, 14, 9, 0))[0], 0)

    def test_early_bird_only_before_8am(self):
        mission = missions.MISSIONS[2]
        late = [self._row("2026-10-12 09:30")]
        early = [self._row("2026-10-12 06:45")]
        self.assertEqual(missions.progress(mission, late, datetime(2026, 10, 14))[0], 0)
        self.assertEqual(missions.progress(mission, early, datetime(2026, 10, 14))[0], 1)

    def test_new_birds_excludes_species_found_before_this_week(self):
        mission = missions.MISSIONS[3]
        rows = [
            self._row("2026-09-20 07:00"),  # House Crow found long ago
            self._row("2026-10-12 07:00"),  # House Crow again: not new
            self._row("2026-10-12 07:05", sci="Acridotheres tristis", common="Common Myna"),
        ]
        self.assertEqual(missions.progress(mission, rows, datetime(2026, 10, 14))[0], 1)

    def test_places_count_distinct_named_places(self):
        mission = missions.MISSIONS[4]
        rows = [self._row("2026-10-12 07:00", place="Pashan Lake"),
                self._row("2026-10-13 07:00", place="pashan lake"),
                self._row("2026-10-14 07:00", place="Vetal Hill"),
                self._row("2026-10-14 07:10", place="")]
        self.assertEqual(missions.progress(mission, rows, datetime(2026, 10, 14))[0], 2)


class TestBingo(TempData):
    def test_card_ticks_by_common_or_scientific_name(self):
        card = bingo.starter_card()
        card["created"] = "2026-10-01"
        rows = [
            store.make_row(datetime(2026, 10, 12, 7, 0), "a.wav", "found", "Corvus splendens", "House Crow", 0.9),
            store.make_row(datetime(2026, 10, 12, 7, 0), "a.wav", "found", "", "Common Myna", 0.8),
            store.make_row(datetime(2026, 10, 12, 7, 0), "a.wav", "maybe", "Columba livia", "Rock Pigeon", 0.3),
        ]
        flags = bingo.ticked(card, rows)
        self.assertEqual(flags[:3], [True, True, False])  # a "maybe" never ticks a square

    def test_sightings_before_card_start_do_not_count(self):
        card = bingo.starter_card()
        card["created"] = "2026-10-20"
        rows = [store.make_row(datetime(2026, 10, 12), "a.wav", "found", "Corvus splendens", "House Crow", 0.9)]
        self.assertFalse(any(bingo.ticked(card, rows)))

    def test_bingo_lines(self):
        top_row = [True, True, True] + [False] * 6
        self.assertEqual(bingo.bingo_lines(top_row), 1)
        self.assertEqual(bingo.bingo_lines([False] * 9), 0)
        self.assertEqual(bingo.bingo_lines([True] * 9), 8)

    def test_card_from_species_list_picks_nine_from_top_30(self):
        species = [(f"Genus sp{i}", f"Bird {i}") for i in range(60)]
        card = bingo.card_from_species_list(species, seed=1)
        self.assertEqual(len(card["birds"]), 9)
        self.assertTrue(all(int(b["common"].split()[1]) < 30 for b in card["birds"]))

    def test_load_card_creates_starter_card_once(self):
        first = bingo.load_card()
        self.assertTrue(bingo.card_path().is_file())
        self.assertEqual(first, bingo.load_card())


class TestListenEndToEnd(TempData):
    def run_listen(self, *extra):
        detections = birdnet_runner.parse_results_csv(FIXTURE)
        out = io.StringIO()
        with mock.patch.object(birdnet_runner, "run_birdnet", return_value=detections), \
             mock.patch.object(notes, "field_note", return_value=("A fine bird. Listen for it.", "ollama")), \
             contextlib.redirect_stdout(out):
            code = quest.main(["listen", "morning.wav", "--when", "2026-10-12 07:15", *extra])
        return code, out.getvalue()

    def test_listen_logs_and_reports(self):
        code, text = self.run_listen("--place", "Pashan Lake")
        self.assertEqual(code, 0)
        self.assertIn("House Crow", text)
        self.assertIn("Asian Koel", text)
        self.assertIn("Maybe (not counted", text)  # Common Myna was only 34%
        self.assertIn("Bingo: ticked", text)
        self.assertIn("This week's mission", text)
        rows = store.load_sightings()
        self.assertEqual([r["status"] for r in rows], ["found", "found", "maybe"])
        self.assertEqual(rows[0]["place"], "Pashan Lake")

    def test_maybe_bird_is_not_ticked_on_bingo(self):
        self.run_listen()
        card = bingo.load_card()
        flags = bingo.ticked(card, store.load_sightings())
        names = [b["common"] for b in card["birds"]]
        self.assertTrue(flags[names.index("House Crow")])
        self.assertFalse(flags[names.index("Common Myna")])

    def test_missing_file_gives_friendly_message(self):
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            code = quest.main(["listen", "does_not_exist.wav"])
        self.assertEqual(code, 1)
        self.assertIn("cannot find the recording", out.getvalue())

    def test_no_birds_still_counts_as_a_walk(self):
        out = io.StringIO()
        with mock.patch.object(birdnet_runner, "run_birdnet", return_value=[]), \
             contextlib.redirect_stdout(out):
            quest.main(["listen", "quiet.wav", "--when", "2026-10-12 07:15"])
        self.assertEqual(store.load_sightings()[0]["status"], "none")
        self.assertIn("No bird heard", out.getvalue())


if __name__ == "__main__":
    unittest.main()

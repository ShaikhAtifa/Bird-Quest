# Setup on Windows (about 45 minutes, most of it waiting for downloads)

Do these steps in order. Do them at home, **with internet**. After step 7, the project works with no internet.

## 1. Install Python 3.12

1. Go to **python.org/downloads** and download Python **3.12**.
2. Run the installer. On the first screen, **tick "Add python.exe to PATH"**. This is very important.
3. Click "Install Now".

## 2. Open the project folder in Command Prompt

1. Open this project folder in File Explorer.
2. Click the address bar at the top, type `cmd`, press Enter. A black window opens, already inside the folder.

Use **Command Prompt**, not PowerShell. PowerShell sometimes blocks the next step.

## 3. Make a clean box for the project

```
python -m venv .venv
.venv\Scripts\activate
```

You should see `(.venv)` at the start of the line. Every time you open a new Command Prompt for this project, run the second line again.

## 4. Install BirdNET

```
pip install -r requirements.txt
```

This is a big download because BirdNET uses TensorFlow. It can take 5 to 15 minutes. Wait for it.

## 5. Install Ollama and the small AI model

1. Download Ollama from **ollama.com** and install it. Open the Ollama app once so it runs in the background.
2. In Command Prompt:

```
ollama pull qwen2.5:1.5b
```

## 6. Download BirdNET's model (one time only)

```
python quest.py warmup
```

BirdNET downloads its bird-sound model the first time it runs. This is the step that needs internet. When it says "Done", BirdNET can work offline.

## 7. Check everything

```
python quest.py check
```

You want to see three good lines: Python, BirdNET, Ollama. If something says PROBLEM or NOT, the line tells you the fix.

## 8. Test it BEFORE you go outside

1. Download any short bird recording (10 to 30 seconds). Free ones are on **xeno-canto.org**. Write down the author and the licence in your devlog.
2. Put the file in the `recordings` folder.
3. Run:

```
python quest.py listen recordings\your_file.mp3
```

If you see a bird name and a short note, everything works. Now you are ready for the real test outside.

## Going outside (the real test)

1. Record 30 to 60 seconds of bird sounds with your phone's voice recorder. Hold still and keep quiet.
2. Move the file to your laptop (USB cable, or send it to yourself on WhatsApp or email).
3. Run `python quest.py listen recordings\morning.m4a --place "Pashan Lake" --when "2026-10-12 07:15"`.
   Use `--when` for the time you **recorded**, because the early-bird mission needs it.
4. Or take the laptop with you and run it on the spot. Turn Wi-Fi off first to prove it works offline.

## If something goes wrong

Copy the full error message into `docs/devlog.md`. Errors are good material for your write-up. If the error is a bug in BirdNET or Ollama's instructions, it may also be your first open-source contribution.

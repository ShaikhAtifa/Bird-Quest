# Devlog

Write here **while you work**, not at the end. Two minutes per entry is enough.
Judges read your write-up, and real notes make real writing. Delete this
instruction block when you start.

For each entry, answer: What did I try? What happened? What surprised me?

---

## Template (copy this for each entry)

### [Date, time]  [Short title]
- **Tried:**
- **Happened:** (paste exact error messages)
- **Surprised me:**
- **Next:**

---

## Things worth recording (do not skip these)

- [ ] How long each install step took, and how big the downloads were
- [ ] Every error message and how you fixed it
- [ ] Your first bird identified: which file, which bird, how sure BirdNET was
- [ ] A recording BirdNET got wrong or was unsure about
- [ ] How long one AI field note took on your laptop (seconds)
- [ ] The moment you were outside and noticed something you would have missed
- [ ] How many times you looked at the screen during the walk
- [ ] Licence and author of any recording you did not make yourself

## Entries

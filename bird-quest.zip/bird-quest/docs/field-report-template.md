# Field test report

This is the most important page of your project. Fill it in **outside, or right
after**, while you still remember. Use real numbers. Do not write what you
expect to happen. Write what happened. Mistakes make it better.

## The walks

| # | Date | Place | Time of day | Weather | Minutes outside | Recording length |
|---|------|-------|-------------|---------|-----------------|------------------|
| 1 |      |       |             |         |                 |                  |
| 2 |      |       |             |         |                 |                  |
| 3 |      |       |             |         |                 |                  |

Was the laptop **offline** during the test? (yes / no)

## Results

Your `data/sightings.csv` has every detection. Count honestly.

| Walk | Birds BirdNET named | I could check by eye or ear | BirdNET was right | BirdNET was wrong | "Maybe" (under 50%) |
|------|---------------------|-----------------------------|-------------------|-------------------|---------------------|
| 1    |                     |                             |                   |                   |                     |
| 2    |                     |                             |                   |                   |                     |

How did you check? (a second app, a bird book, a person who knows birds, your own eyes)

## The AI field notes

- Seconds to write one note on my laptop:
- Notes that were correct:
- Notes that had a mistake (write the mistake):

## The screen test

- Times I looked at the screen during the walk:
- Minutes I looked at the screen in total:
- Minutes I was outside:

## Did the mission get me outside?

- This week's mission was:
- Did I finish it? (yes / no)
- Would I have gone outside on that day without it? (be honest)
- One moment I would have missed if I had stayed home:

## What failed

(wind, traffic noise, a bird that was too far, a phone recording that was too quiet, a bug)

## What I would change next


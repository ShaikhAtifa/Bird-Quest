"""Field notes written by a small AI model that runs on YOUR laptop (via Ollama).

No internet is needed after you download the model once. If Ollama is not
running, Bird Quest still works and uses a plain fallback note.
"""

import json
import re
import urllib.error
import urllib.request

import config


def build_prompt(common: str, scientific: str) -> str:
    return (
        "You are a friendly bird guide talking to a beginner.\n"
        f"Bird: {common} ({scientific}).\n"
        "Write exactly 2 short sentences in very simple English.\n"
        "Sentence 1: one simple fact about where it lives or how it behaves.\n"
        "Sentence 2: one tip to recognise its sound or looks next time.\n"
        "If you are not sure about a fact, say \"I am not sure\" instead of guessing.\n"
        "No lists, no emojis, no extra text."
    )


def fallback_note(common: str) -> str:
    return (
        f"No AI note this time. Look up the {common} in a bird book or app "
        "and compare its call with your recording."
    )


def field_note(common: str, scientific: str) -> tuple[str, str]:
    """Return (note, source). source is "ollama" or "fallback"."""
    payload = json.dumps(
        {
            "model": config.OLLAMA_MODEL,
            "prompt": build_prompt(common, scientific),
            "stream": False,
            "options": {"temperature": 0.4, "num_predict": 120},
        }
    ).encode("utf-8")
    request = urllib.request.Request(
        f"{config.OLLAMA_HOST}/api/generate",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=config.OLLAMA_TIMEOUT_SECONDS) as response:
            body = json.loads(response.read().decode("utf-8"))
        text = re.sub(r"\s+", " ", body.get("response", "")).strip()
        if not text:
            return fallback_note(common), "fallback"
        return text[:400], "ollama"
    except (urllib.error.URLError, TimeoutError, OSError, ValueError):
        return fallback_note(common), "fallback"


def ollama_status() -> tuple[bool, list[str]]:
    """Is Ollama running? Which models are downloaded?"""
    try:
        with urllib.request.urlopen(f"{config.OLLAMA_HOST}/api/tags", timeout=5) as response:
            body = json.loads(response.read().decode("utf-8"))
        return True, [m.get("name", "") for m in body.get("models", [])]
    except (urllib.error.URLError, TimeoutError, OSError, ValueError):
        return False, []

"""Weekly missions. The mission cannot be finished from your sofa:
every kind needs a recording made outside.

Weeks run Monday to Sunday. The mission changes every week.
"""

from datetime import date, datetime, timedelta

import config
from store import row_time, species_key

MISSIONS = [
    {"id": "species5", "kind": "species", "target": 5,
     "title": "Find 5 different birds by sound"},
    {"id": "walks3", "kind": "walks", "target": 3,
     "title": "Go outside and record on 3 different days"},
    {"id": "early1", "kind": "early", "target": 1,
     "title": f"Be an early bird: record a bird before {config.EARLY_BIRD_HOUR} AM"},
    {"id": "new2", "kind": "new", "target": 2,
     "title": "Find 2 birds you have never found before"},
    {"id": "places2", "kind": "places", "target": 2,
     "title": "Record in 2 different places (use --place to name them)"},
]


def week_bounds(when: datetime) -> tuple[date, date]:
    """Monday and Sunday of the week that contains `when`."""
    monday = when.date() - timedelta(days=when.weekday())
    return monday, monday + timedelta(days=6)


def mission_for(when: datetime) -> dict:
    return MISSIONS[when.isocalendar().week % len(MISSIONS)]


def progress(mission: dict, sightings: list[dict], when: datetime) -> tuple[int, int]:
    """Return (done so far, target) for this week."""
    monday, sunday = week_bounds(when)
    this_week = [r for r in sightings if monday <= row_time(r).date() <= sunday]
    found = [r for r in this_week if r["status"] == "found"]
    kind = mission["kind"]

    if kind == "species":
        done = len({species_key(r) for r in found})
    elif kind == "walks":
        done = len({row_time(r).date() for r in this_week})
    elif kind == "early":
        done = len({row_time(r).date() for r in found if row_time(r).hour < config.EARLY_BIRD_HOUR})
    elif kind == "new":
        seen_before = {species_key(r) for r in sightings
                       if r["status"] == "found" and row_time(r).date() < monday}
        done = len({species_key(r) for r in found} - seen_before)
    elif kind == "places":
        done = len({r["place"].strip().casefold() for r in this_week if r["place"].strip()})
    else:
        done = 0
    return done, mission["target"]


def describe(when: datetime, sightings: list[dict]) -> str:
    mission = mission_for(when)
    done, target = progress(mission, sightings, when)
    state = "DONE!" if done >= target else f"{done}/{target}"
    return f"This week's mission: {mission['title']}  [{state}]"

"""Bird Quest - a weekly bird mission that only you can finish by going outside.

Commands:
  python quest.py check                  is everything installed?
  python quest.py warmup                 one-time BirdNET model download (needs internet)
  python quest.py mission                this week's mission and your progress
  python quest.py listen FILE            analyze a recording you made outside
  python quest.py card                   show your bingo card
  python quest.py newcard                make a new card from birds near you
  python quest.py history                your last 15 sightings
"""

import argparse
import importlib.util
import platform
import subprocess
import sys
import tempfile
import wave
from datetime import datetime
from pathlib import Path

import bingo
import birdnet_runner
import config
import missions
import notes
import store


def _say(text: str = "") -> None:
    print(text, flush=True)


def _parse_when(text: str | None) -> datetime:
    if not text:
        return datetime.now()
    try:
        return datetime.strptime(text, "%Y-%m-%d %H:%M")
    except ValueError:
        raise SystemExit('Please write the time like this: "2026-10-11 07:30"')


def speak(text: str) -> None:
    """Read a note aloud so you can keep the phone in your pocket.
    Windows only. Uses the voice already built into Windows."""
    if platform.system() != "Windows":
        _say("  (--speak only works on Windows.)")
        return
    safe = text.replace("'", "''")
    script = (
        "Add-Type -AssemblyName System.Speech; "
        f"(New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{safe}')"
    )
    try:
        subprocess.run(["powershell", "-NoProfile", "-Command", script], timeout=60, check=False)
    except (OSError, subprocess.SubprocessError):
        _say("  (Could not speak the note.)")


# ---------------------------------------------------------------- commands

def cmd_listen(args) -> int:
    when = _parse_when(args.when)
    before = store.load_sightings()
    card = bingo.load_card()
    flags_before = bingo.ticked(card, before)

    _say(f"Listening to {args.file} ...")
    try:
        detections = birdnet_runner.run_birdnet(args.file, when=when, debug=args.debug)
    except (FileNotFoundError, birdnet_runner.BirdNetError) as err:
        _say(str(err))
        return 1

    best = birdnet_runner.best_per_species(detections)
    found = [d for d in best if d.confidence >= config.CONFIRM_CONFIDENCE]
    maybe = [d for d in best if d.confidence < config.CONFIRM_CONFIDENCE]
    rows = []

    if not best:
        _say("No bird heard above "
             f"{config.MIN_CONFIDENCE:.0%} sure. Try a longer or closer recording.")
        rows.append(store.make_row(when, args.file, "none", place=args.place))

    if found:
        _say("Found:")
    for d in found[: args.max_notes]:
        note, source = notes.field_note(d.common, d.scientific)
        _say(f"  {d.common} ({d.scientific})  {d.confidence:.0%} sure")
        _say(f"    {note}" + ("" if source == "ollama" else "  [no AI]"))
        rows.append(store.make_row(when, args.file, "found", d.scientific, d.common,
                                   d.confidence, args.place, note))
        if args.speak:
            speak(f"{d.common}. {note}")
    for d in found[args.max_notes:]:
        _say(f"  {d.common} ({d.scientific})  {d.confidence:.0%} sure")
        rows.append(store.make_row(when, args.file, "found", d.scientific, d.common,
                                   d.confidence, args.place))

    if maybe:
        _say(f"Maybe (not counted, under {config.CONFIRM_CONFIDENCE:.0%} sure):")
        for d in maybe:
            _say(f"  {d.common}  {d.confidence:.0%}")
            rows.append(store.make_row(when, args.file, "maybe", d.scientific, d.common,
                                       d.confidence, args.place))

    store.add_rows(rows)
    after = store.load_sightings()
    flags_after = bingo.ticked(card, after)
    new_ticks = [card["birds"][i]["common"]
                 for i, (was, now) in enumerate(zip(flags_before, flags_after)) if now and not was]
    _say()
    if new_ticks:
        _say(f"Bingo: ticked {', '.join(new_ticks)}  ({sum(flags_after)}/{len(flags_after)})")
    _say(missions.describe(when, after))
    return 0


def cmd_mission(args) -> int:
    _say(missions.describe(datetime.now(), store.load_sightings()))
    return 0


def cmd_card(args) -> int:
    card = bingo.load_card()
    _say(bingo.render(card, bingo.ticked(card, store.load_sightings())))
    return 0


def cmd_newcard(args) -> int:
    _say("Asking BirdNET which birds live near you (this can take a minute) ...")
    try:
        species = birdnet_runner.list_local_species()
        card = bingo.card_from_species_list(species)
    except (birdnet_runner.BirdNetError, ValueError) as err:
        _say(str(err))
        return 1
    bingo.save_card(card)
    _say("New card saved. Only birds found from today count on this card.\n")
    _say(bingo.render(card, [False] * len(card["birds"])))
    return 0


def cmd_history(args) -> int:
    rows = store.load_sightings()[-15:]
    if not rows:
        _say("No sightings yet. Go outside, record a bird, and run: python quest.py listen FILE")
        return 0
    for r in rows:
        who = r["common"] or "(no bird heard)"
        conf = f"  {float(r['confidence']):.0%}" if r["confidence"] else ""
        place = f"  @ {r['place']}" if r["place"] else ""
        _say(f"{r['timestamp']}  {r['status']:<5}  {who}{conf}{place}")
    return 0


def cmd_warmup(args) -> int:
    """Do the one-time BirdNET model download while you still have internet."""
    silence = Path(tempfile.mkdtemp(prefix="birdquest_")) / "silence.wav"
    with wave.open(str(silence), "wb") as handle:
        handle.setnchannels(1)
        handle.setsampwidth(2)
        handle.setframerate(48000)
        handle.writeframes(b"\x00\x00" * 48000 * 3)  # 3 seconds of silence
    _say("Starting BirdNET. The first time, it downloads its model (needs internet, a few minutes) ...")
    try:
        birdnet_runner.run_birdnet(silence, debug=args.debug)
    except birdnet_runner.BirdNetError as err:
        _say(str(err))
        return 1
    _say("Done. BirdNET is ready and will now work with NO internet.")
    return 0


def cmd_check(args) -> int:
    ok = True
    _say(f"Python {platform.python_version()}")
    if sys.version_info < (3, 11):
        ok = False
        _say("  PROBLEM: BirdNET needs Python 3.11 or newer.")
    if importlib.util.find_spec("birdnet_analyzer") is None:
        ok = False
        _say("BirdNET: NOT installed.  Fix: pip install -r requirements.txt")
    elif not birdnet_runner.model_downloaded():
        ok = False
        _say("BirdNET: installed, but its model file is not downloaded yet.\n"
             "  Fix (needs internet, once): python quest.py warmup")
    else:
        _say("BirdNET: installed, model downloaded (works offline)")
    running, models = notes.ollama_status()
    if not running:
        ok = False
        _say("Ollama: NOT running.  Fix: install it from ollama.com and open the app.")
    elif not any(m == config.OLLAMA_MODEL or m.startswith(config.OLLAMA_MODEL + ":") for m in models):
        ok = False
        _say(f"Ollama: running, but model {config.OLLAMA_MODEL} is missing.  "
             f"Fix: ollama pull {config.OLLAMA_MODEL}")
    else:
        _say(f"Ollama: running, model {config.OLLAMA_MODEL} ready")
    _say("\nAll good. Go outside!" if ok else "\nFix the problems above, then run check again.")
    return 0 if ok else 1


# ------------------------------------------------------------------- main

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="quest.py", description="Bird Quest")
    sub = parser.add_subparsers(dest="command", required=True)

    listen = sub.add_parser("listen", help="analyze a recording")
    listen.add_argument("file", help="audio file: wav, mp3, m4a, ogg, flac")
    listen.add_argument("--place", default="", help='name of the place, e.g. "Pashan lake"')
    listen.add_argument("--when", help='when you recorded it, e.g. "2026-10-11 07:30" (default: now)')
    listen.add_argument("--max-notes", type=int, default=3, help="write AI notes for this many birds")
    listen.add_argument("--speak", action="store_true", help="read notes aloud (Windows only)")
    listen.add_argument("--debug", action="store_true", help="show BirdNET's own messages")
    listen.set_defaults(func=cmd_listen)

    for name, func, text in [
        ("mission", cmd_mission, "show this week's mission"),
        ("card", cmd_card, "show the bingo card"),
        ("newcard", cmd_newcard, "make a new card from BirdNET's list for your area"),
        ("history", cmd_history, "show recent sightings"),
        ("check", cmd_check, "check that everything is installed"),
    ]:
        sub.add_parser(name, help=text).set_defaults(func=func)

    warmup = sub.add_parser("warmup", help="download BirdNET's model once (needs internet)")
    warmup.add_argument("--debug", action="store_true", help="show BirdNET's own messages")
    warmup.set_defaults(func=cmd_warmup)
    return parser


def main(argv=None) -> int:
    if hasattr(sys.stdout, "reconfigure"):  # avoids crashes on Windows consoles
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())

"""The 3x3 bingo card. A square is ticked when you really find that bird."""

import json
import random
from datetime import datetime

import config
import store
from store import row_time

GRID = 3


def card_path():
    return config.DATA_DIR / "bingo_card.json"


def starter_card() -> dict:
    """A first card of common birds, so Bird Quest works on day one.
    Run `python quest.py newcard` for a card made from BirdNET's own list for
    your area, which is better because the names match exactly."""
    birds = [
        ("Corvus splendens", "House Crow"),
        ("Acridotheres tristis", "Common Myna"),
        ("Columba livia", "Rock Pigeon"),
        ("Eudynamys scolopaceus", "Asian Koel"),
        ("Pycnonotus cafer", "Red-vented Bulbul"),
        ("Cinnyris asiaticus", "Purple Sunbird"),
        ("Copsychus saularis", "Oriental Magpie-Robin"),
        ("Psittacula krameri", "Rose-ringed Parakeet"),
        ("Psilopogon haemacephalus", "Coppersmith Barbet"),
    ]
    return _make_card(birds, "starter")


def _make_card(birds: list[tuple[str, str]], origin: str) -> dict:
    return {
        "created": datetime.now().strftime("%Y-%m-%d"),
        "origin": origin,
        "birds": [{"scientific": s, "common": c} for s, c in birds[: GRID * GRID]],
    }


def card_from_species_list(species: list[tuple[str, str]], seed: int | None = None) -> dict:
    """Pick 9 birds at random from the 30 most common ones near you."""
    pool = species[:30]
    if len(pool) < GRID * GRID:
        raise ValueError("BirdNET gave fewer than 9 species for your area.")
    rng = random.Random(seed)
    return _make_card(rng.sample(pool, GRID * GRID), "birdnet-local-list")


def load_card() -> dict:
    path = card_path()
    if path.is_file():
        return json.loads(path.read_text(encoding="utf-8"))
    card = starter_card()
    save_card(card)
    return card


def save_card(card: dict) -> None:
    path = card_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(card, indent=2, ensure_ascii=False), encoding="utf-8")


def ticked(card: dict, sightings: list[dict]) -> list[bool]:
    """One True/False per square. Only sightings from the card's start date count."""
    start = datetime.strptime(card["created"], "%Y-%m-%d").date()
    found = set()
    for row in sightings:
        if row["status"] == "found" and row_time(row).date() >= start:
            found.add(row["scientific"].casefold())
            found.add(row["common"].casefold())
    return [
        bird["scientific"].casefold() in found or bird["common"].casefold() in found
        for bird in card["birds"]
    ]


def bingo_lines(flags: list[bool]) -> int:
    """How many full rows, columns or diagonals are ticked."""
    if len(flags) < GRID * GRID:
        return 0
    grid = [flags[r * GRID:(r + 1) * GRID] for r in range(GRID)]
    lines = [list(row) for row in grid]
    lines += [[grid[r][c] for r in range(GRID)] for c in range(GRID)]
    lines.append([grid[i][i] for i in range(GRID)])
    lines.append([grid[i][GRID - 1 - i] for i in range(GRID)])
    return sum(all(line) for line in lines)


def render(card: dict, flags: list[bool]) -> str:
    width = 26
    rows = []
    for r in range(GRID):
        cells = []
        for c in range(GRID):
            i = r * GRID + c
            if i >= len(card["birds"]):
                cells.append(" " * width)
                continue
            mark = "[x]" if flags[i] else "[ ]"
            cells.append(f"{mark} {card['birds'][i]['common'][:width - 5]}".ljust(width))
        rows.append("".join(cells).rstrip())
    done = sum(flags)
    lines = bingo_lines(flags)
    footer = f"{done}/{GRID * GRID} birds found" + (f"  -  BINGO x{lines}!" if lines else "")
    return "\n".join(rows + ["", footer])
